import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // useNavigate 추가

import '../styles/LoginPage.css';

const LoginPage = () => {
  const [activeDot, setActiveDot] = useState(0);
  const navigate = useNavigate(); // 페이지 이동을 위한 훅

  const handleLogin = (e) => {
    e.preventDefault();

    // 실제 로그인 로직이 들어갈 부분 (예: 백엔드 인증 요청)
    // 여기선 임시로 바로 메인 페이지로 이동시킴
    console.log("로그인 시도");

    navigate('/home'); // 메인 페이지로 이동
  };

  const descriptions = [
    {
      title: "Connecting Talent to Opportunities",
      text: "Discover endless opportunities on FreelanceConnect, where talented freelancers and businesses unite. Jump right in with us!",
      user: "Daphne Park | UI/UX Designer"
    },
    {
      title: "Find the Best Gigs for You",
      text: "FreelanceConnect offers tailored opportunities based on your skills. We make it easy for you to discover the perfect job!",
      user: "John Doe | Web Developer"
    },
    {
      title: "Showcase Your Skills",
      text: "FreelanceConnect lets you showcase your portfolio and expertise, making it easy for clients to find you.",
      user: "Alice Johnson | Graphic Designer"
    }
  ];

  return (
    <div className="signup-container">
      <div className="left-panel">
        <div className="left-panel-content">
          {descriptions.map((description, index) => (
            <div
              key={index}
              className={`slide-content ${activeDot === index ? 'active' : ''}`}
              style={{
                transform: `translateX(${activeDot === index ? '0%' : '100%'})`,
              }}
            >
              <h2>{description.title}</h2>
              <p>{description.text}</p>
              <p><b>{description.user}</b></p>
            </div>
          ))}
        </div>
        <div className="indicator-container">
          {descriptions.map((_, index) => (
            <div
              key={index}
              className={`indicator-dot ${activeDot === index ? 'active' : ''}`}
              onClick={() => setActiveDot(index)}
            ></div>
          ))}
        </div>
      </div>
      <div className="right-panel">
        <div className="form-container">
          <h2>Welcome to FreelanceHu👋</h2>
          <p>Kindly fill in your details below to create an account</p>
          <form onSubmit={handleLogin}>
            <input className="input-field" type="email" placeholder="Email Address" required />
            <input className="input-field" type="password" placeholder="Password" required />
            <button className="button" type="submit">Login</button>
          </form>
          <p>계정이 없으신가요? <Link to="/create-account">Create Account</Link></p>
          <div className="social-login">
            <button className="google-btn">Google</button>
            <button className="apple-btn">Apple</button>
            <button className="twitter-btn">Twitter</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
