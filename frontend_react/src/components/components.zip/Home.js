import React from 'react';

const Home = () => {
  return (
    <div style={{ padding: '40px' }}>
      <h1>🎉 메인 페이지입니다!</h1>
      <p>로그인 성공 후 이 페이지로 이동했습니다.</p>
    </div>
  );
};

export default Home;
